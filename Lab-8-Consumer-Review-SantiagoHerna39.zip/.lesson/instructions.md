# Instructions  

  
  ## Activity 1
  1. Complete the Worksheet provdied in class. Learn how the sentimentaVal method works.
       ## Activity 2.
  2. Use the sentimentVal method, loops and string methods to find an overall sentiment value for reviews you found online.  Then give it a star rating.  This will require string processing throughout the review, including identifying a word, and then removing punctuation from it, and finally checking it's sentimentValue.  The punctuation removal method is provided for you in the starter code, are the methods to read a review from a text file, into a string.
     ## Activity 3.
  3.  In  this activity students will automatically modify a review to swap out positive or negative adjitives and change the overall sentiment of the reivew.
   ## Activity 4. 
  4. Activity for should be undertaken if you finish activity 3 early.    
   This activity takes reviews and makes them more extreme, either MORE positive, or MORE negative.
  