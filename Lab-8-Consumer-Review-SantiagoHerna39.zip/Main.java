class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    Review critic = new Review();

    System.out.println(Review.totalSentiment("SimpleReview.txt"));
  }
}